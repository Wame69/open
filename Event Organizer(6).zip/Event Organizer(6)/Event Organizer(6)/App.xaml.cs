﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Event_Organizer_6_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
