﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace The__Virtual_Textbook__application_10_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
