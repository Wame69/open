﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace HabitTracker
{
    public partial class MainWindow : Window
    {
        private List<Habit> habits = new List<Habit>();
        private const string dataFilePath = "habits.json";
        public MainWindow()
        {
            InitializeComponent();
            PlaceholderText.Visibility = Visibility.Visible; LoadData();
        }

        private void HabitNameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(HabitNameTextBox.Text))
            {
                PlaceholderText.Visibility = Visibility.Collapsed;
            }
            else
            {
                PlaceholderText.Visibility = Visibility.Visible;
            }
        }

        private void AddHabit_Click(object sender, RoutedEventArgs e)
        {
            string habitName = HabitNameTextBox.Text.Trim();
            if (!string.IsNullOrEmpty(habitName))
            {
                habits.Add(new Habit { Name = habitName, Progress = 0 });
                HabitsList.ItemsSource = null; HabitsList.ItemsSource = habits;
                HabitNameTextBox.Clear(); PlaceholderText.Visibility = Visibility.Visible;
            }
        }

        private void IncreaseProgress_Click(object sender, RoutedEventArgs e)
        {
            if (HabitsList.SelectedItem is Habit selectedHabit)
            {
                selectedHabit.Progress += 10; if (selectedHabit.Progress > 100) selectedHabit.Progress = 100; 
                HabitsList.ItemsSource = null; HabitsList.ItemsSource = habits;
            }
        }

        private void SaveData_Click(object sender, RoutedEventArgs e)
        {
            SaveData();
        }

        private void SaveData()
        {
            string json = JsonSerializer.Serialize(habits);
            File.WriteAllText(dataFilePath, json);
            MessageBox.Show("Данные сохранены!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LoadData()
        {
            if (File.Exists(dataFilePath))
            {
                string json = File.ReadAllText(dataFilePath);
                habits = JsonSerializer.Deserialize<List<Habit>>(json) ?? new List<Habit>();
                HabitsList.ItemsSource = habits;
            }
        }
    }

    public class Habit
    {
        public string Name { get; set; }
        public double Progress { get; set; }
    }
}
