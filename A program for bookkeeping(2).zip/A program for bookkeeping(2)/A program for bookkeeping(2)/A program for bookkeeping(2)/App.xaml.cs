﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace A_program_for_bookkeeping_2_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
